
  # Admin and General User Dashboard

  This is a code bundle for Admin and General User Dashboard. The original project is available at https://www.figma.com/design/87DDNImjXwg8EOHARTcXDQ/Admin-and-General-User-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  