import { useState, useEffect } from 'react';
import { Loader2, Table } from 'lucide-react';
import { DataTable } from './DataTable';
import { getRecords } from '../services/api';

interface UserDataViewerProps {
    category: string;
}

export function UserDataViewer({ category }: UserDataViewerProps) {
    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);

    const fetchRecords = async () => {
        setLoading(true);
        try {
            const records = await getRecords(category);
            setData(records);
        } catch (error) {
            console.error('Failed to fetch records:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchRecords();
    }, [category]);

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                    <div className="p-2 bg-teal-100 rounded-lg">
                        <Table className="size-5 text-teal-600" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-800">Tabular View</h3>
                </div>
                {loading && <Loader2 className="size-5 text-teal-600 animate-spin" />}
            </div>

            <div className="bg-white rounded-xl shadow-inner border border-teal-50 overflow-hidden">
                <DataTable data={data} reportType={category} />
            </div>

            {!loading && data.length === 0 && (
                <div className="text-center py-8 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                    <p className="text-gray-500">No records found for this section.</p>
                </div>
            )}
        </div>
    );
}
