import { useState, useMemo } from 'react';
import { ChevronUp, ChevronDown, Search, Edit2, Trash2 } from 'lucide-react';

interface DataTableProps {
  data: any[];
  reportType: string;
  onDelete?: (index: number) => void;
  onEdit?: (index: number) => void;
}

export function DataTable({ data, reportType, onDelete, onEdit }: DataTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const itemsPerPage = 10;

  // Get columns from data
  const columns = data.length > 0 ? Object.keys(data[0]) : [];

  // Filter data based on search
  const filteredData = useMemo(() => {
    if (!searchTerm) return data;
    
    return data.filter((row) =>
      Object.values(row).some((value) =>
        String(value).toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }, [data, searchTerm]);

  // Sort data
  const sortedData = useMemo(() => {
    if (!sortColumn) return filteredData;

    return [...filteredData].sort((a, b) => {
      const aVal = a[sortColumn];
      const bVal = b[sortColumn];

      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredData, sortColumn, sortDirection]);

  // Paginate data
  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage]);

  const totalPages = Math.ceil(sortedData.length / itemsPerPage);

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const formatColumnName = (column: string) => {
    return column
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, (str) => str.toUpperCase())
      .trim();
  };

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-400 size-5" />
        <input
          type="text"
          placeholder="Search across all columns..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
          className="w-full pl-10 pr-4 py-3 border-2 border-purple-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
        />
      </div>

      {/* Table */}
      <div className="overflow-x-auto border-2 border-purple-100 rounded-xl shadow-lg">
        <table className="min-w-full divide-y divide-purple-100">
          <thead className="bg-gradient-to-r from-purple-50 to-indigo-50">
            <tr>
              {columns.map((column) => (
                <th
                  key={column}
                  onClick={() => handleSort(column)}
                  className="px-6 py-4 text-left text-xs text-purple-700 uppercase tracking-wider cursor-pointer hover:bg-purple-100 transition-colors font-bold"
                >
                  <div className="flex items-center gap-2">
                    {formatColumnName(column)}
                    <div className="flex flex-col">
                      <ChevronUp
                        className={`size-3 ${
                          sortColumn === column && sortDirection === 'asc'
                            ? 'text-purple-600'
                            : 'text-gray-400'
                        }`}
                      />
                      <ChevronDown
                        className={`size-3 -mt-1 ${
                          sortColumn === column && sortDirection === 'desc'
                            ? 'text-purple-600'
                            : 'text-gray-400'
                        }`}
                      />
                    </div>
                  </div>
                </th>
              ))}
              {(onEdit || onDelete) && (
                <th className="px-6 py-4 text-left text-xs text-purple-700 uppercase tracking-wider font-bold">
                  Actions
                </th>
              )}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-purple-50">
            {paginatedData.length > 0 ? (
              paginatedData.map((row, rowIndex) => {
                const actualIndex = (currentPage - 1) * itemsPerPage + rowIndex;
                return (
                  <tr key={rowIndex} className="hover:bg-purple-50 transition-colors">
                    {columns.map((column) => (
                      <td key={column} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {row[column]}
                      </td>
                    ))}
                    {(onEdit || onDelete) && (
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex items-center gap-2">
                          {onEdit && (
                            <button
                              onClick={() => onEdit(actualIndex)}
                              className="p-2 hover:bg-indigo-100 rounded-lg transition-colors group"
                              title="Edit"
                            >
                              <Edit2 className="size-4 text-indigo-600 group-hover:scale-110 transition-transform" />
                            </button>
                          )}
                          {onDelete && (
                            <button
                              onClick={() => onDelete(actualIndex)}
                              className="p-2 hover:bg-red-100 rounded-lg transition-colors group"
                              title="Delete"
                            >
                              <Trash2 className="size-4 text-red-600 group-hover:scale-110 transition-transform" />
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={columns.length + (onEdit || onDelete ? 1 : 0)} className="px-6 py-12 text-center text-gray-500">
                  <div className="flex flex-col items-center">
                    <Search className="size-12 text-gray-300 mb-3" />
                    <p className="text-lg">No data found</p>
                    <p className="text-sm text-gray-400 mt-1">Try adjusting your search criteria</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between bg-white p-4 rounded-lg border border-purple-100">
          <p className="text-sm text-gray-700">
            Showing <span className="font-semibold text-purple-600">{(currentPage - 1) * itemsPerPage + 1}</span> to{' '}
            <span className="font-semibold text-purple-600">{Math.min(currentPage * itemsPerPage, sortedData.length)}</span> of{' '}
            <span className="font-semibold text-purple-600">{sortedData.length}</span> results
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border-2 border-purple-300 text-purple-700 rounded-lg hover:bg-purple-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all font-medium"
            >
              Previous
            </button>
            <div className="flex gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`px-4 py-2 rounded-lg transition-all font-medium ${
                    currentPage === page
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg'
                      : 'border-2 border-purple-200 text-purple-700 hover:bg-purple-50'
                  }`}
                >
                  {page}
                </button>
              ))}
            </div>
            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border-2 border-purple-300 text-purple-700 rounded-lg hover:bg-purple-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all font-medium"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}