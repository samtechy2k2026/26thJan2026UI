import { useState, useRef } from 'react';
import { Upload, File, X, CheckCircle2, AlertTriangle, AlertCircle, Hash, ChevronDown, ChevronUp } from 'lucide-react';
import { EmailReportSection } from './EmailReportSection';

interface PolicyDetailViewProps {
    policyType: string;
    variant?: 'admin' | 'user';
}

interface UploadedDocument {
    name: string;
    size: number;
    type: string;
    content: string;
}

interface ComplianceItem {
    rule: string;
    status: 'compliant' | 'non-compliant';
    description: string;
}

interface PolicyStatus {
    category: string;
    count: number;
    icon: 'active' | 'expiring' | 'validation' | 'expired';
    description: string;
    color: string;
}

export function PolicyDetailView({ policyType, variant = 'user' }: PolicyDetailViewProps) {
    const [uploadedDocument, setUploadedDocument] = useState<UploadedDocument | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const [isUploadSectionExpanded, setIsUploadSectionExpanded] = useState(true);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const themeColors = variant === 'admin'
        ? { primary: 'purple', secondary: 'indigo' }
        : { primary: 'teal', secondary: 'blue' };

    // Simulate file content extraction
    const extractFileContent = (file: File): Promise<string> => {
        return new Promise((resolve) => {
            const reader = new FileReader();

            reader.onload = (e) => {
                const result = e.target?.result as string;

                // Simulate different content based on file type
                let extractedContent = '';

                if (file.type.includes('pdf')) {
                    extractedContent = `POLICY DOCUMENT - ${policyType}
          
Version: 2.1
Effective Date: January 15, 2025
Last Reviewed: January 1, 2025
Next Review Due: July 1, 2025

SECTION 1: PURPOSE AND SCOPE
This policy establishes guidelines and standards for ${policyType.toLowerCase()} within the organization. All employees, contractors, and third-party vendors must comply with these requirements.

SECTION 2: POLICY REQUIREMENTS
1. Access Control: All users must use strong passwords (minimum 12 characters, including uppercase, lowercase, numbers, and special characters).
2. Data Classification: Sensitive data must be encrypted at rest and in transit using AES-256 encryption.
3. Incident Reporting: Security incidents must be reported within 24 hours of discovery.
4. Training: Annual security awareness training is mandatory for all personnel.
5. Compliance Monitoring: Regular audits will be conducted quarterly.

SECTION 3: RESPONSIBILITIES
- IT Department: Implement and maintain security controls
- Department Heads: Ensure team compliance
- All Employees: Follow policy guidelines
- Compliance Officer: Monitor adherence and report violations

SECTION 4: PENALTIES
Non-compliance may result in disciplinary action up to and including termination of employment or contract.

SECTION 5: POLICY REVIEW
This policy will be reviewed annually or when significant changes occur in regulations or technology.`;
                } else if (file.type.includes('word') || file.type.includes('document')) {
                    extractedContent = `${policyType} POLICY GUIDELINES

Document ID: POL-${Math.floor(Math.random() * 10000)}
Status: Active
Department: Human Resources
Owner: Policy Administrator

OVERVIEW:
This document outlines the key requirements and procedures for ${policyType.toLowerCase()}. Compliance with this policy is mandatory for all stakeholders.

KEY REQUIREMENTS:
• Authentication protocols must be followed at all times
• Data retention period: 7 years minimum
• Access rights reviewed quarterly
• Annual certification required for all users
• Encryption required for sensitive data transfers
• Multi-factor authentication enabled for critical systems

COMPLIANCE STANDARDS:
- ISO 27001 Information Security Management
- SOC 2 Type II Compliance
- GDPR Data Protection Requirements
- HIPAA Privacy Standards (where applicable)

EXCEPTIONS:
Requests for exceptions must be submitted in writing and approved by the Security Committee.

EFFECTIVE DATE: January 1, 2025
EXPIRATION DATE: December 31, 2025
REVIEW FREQUENCY: Annual`;
                } else if (file.type.includes('csv') || file.type.includes('excel') || file.type.includes('sheet')) {
                    extractedContent = `POLICY COMPLIANCE TRACKING - ${policyType}

Policy Name,Status,Last Review,Next Review,Compliance Score,Owner
Access Control Policy,Active,2024-12-15,2025-06-15,98%,IT Security
Data Protection Policy,Active,2024-11-20,2025-05-20,95%,Data Officer
Incident Response Policy,Expiring Soon,2024-06-30,2025-01-30,92%,Security Team
Password Policy,Active,2024-12-01,2025-06-01,99%,IT Admin
Encryption Policy,Need Validation,2024-08-15,2025-02-15,88%,Security Lead
Backup Policy,Recently Expired,2024-10-30,2025-01-05,85%,IT Operations
Audit Policy,Active,2024-12-20,2025-06-20,97%,Compliance
Training Policy,Active,2024-11-15,2025-05-15,94%,HR Department

SUMMARY STATISTICS:
Total Policies: 8
Active: 5
Expiring Soon: 1
Need Validation: 1
Recently Expired: 1
Average Compliance Score: 93.5%

NOTES:
- All policies must maintain minimum 90% compliance score
- Quarterly reviews required for critical policies
- Annual comprehensive audit scheduled for Q2 2025`;
                } else {
                    extractedContent = `${policyType} Policy Document

This is a ${file.type} file containing policy information for ${policyType}.

Standard Requirements:
- All users must comply with organizational policies
- Regular training and awareness programs required
- Periodic audits and assessments conducted
- Violations reported and addressed promptly
- Documentation maintained for compliance purposes

Last Updated: January 2025
Status: Under Review
Compliance Rating: Pending Assessment`;
                }

                resolve(extractedContent);
            };

            reader.readAsText(file);
        });
    };

    // Analyze compliance based on content
    const analyzeCompliance = (content: string): ComplianceItem[] => {
        const compliance: ComplianceItem[] = [];

        // Check for key compliance indicators
        if (content.toLowerCase().includes('encryption') && content.toLowerCase().includes('aes-256')) {
            compliance.push({
                rule: 'Data Encryption Standards',
                status: 'compliant',
                description: 'Document specifies AES-256 encryption for data protection'
            });
        } else if (content.toLowerCase().includes('encryption')) {
            compliance.push({
                rule: 'Data Encryption Standards',
                status: 'non-compliant',
                description: 'Encryption mentioned but specific standards not defined'
            });
        }

        if (content.toLowerCase().includes('annual') && content.toLowerCase().includes('training')) {
            compliance.push({
                rule: 'Training Requirements',
                status: 'compliant',
                description: 'Annual training requirements are documented'
            });
        } else {
            compliance.push({
                rule: 'Training Requirements',
                status: 'non-compliant',
                description: 'Training requirements not clearly specified'
            });
        }

        if (content.toLowerCase().includes('incident') && content.toLowerCase().includes('24 hours')) {
            compliance.push({
                rule: 'Incident Reporting Timeline',
                status: 'compliant',
                description: 'Incident reporting within 24 hours is mandated'
            });
        } else if (content.toLowerCase().includes('incident')) {
            compliance.push({
                rule: 'Incident Reporting Timeline',
                status: 'non-compliant',
                description: 'Incident reporting timeline not specified'
            });
        }

        if (content.toLowerCase().includes('review') && (content.toLowerCase().includes('annual') || content.toLowerCase().includes('quarterly'))) {
            compliance.push({
                rule: 'Policy Review Frequency',
                status: 'compliant',
                description: 'Regular policy review schedule is defined'
            });
        } else {
            compliance.push({
                rule: 'Policy Review Frequency',
                status: 'non-compliant',
                description: 'Policy review schedule not specified'
            });
        }

        if (content.toLowerCase().includes('multi-factor') || content.toLowerCase().includes('mfa') || content.toLowerCase().includes('2fa')) {
            compliance.push({
                rule: 'Multi-Factor Authentication',
                status: 'compliant',
                description: 'Multi-factor authentication requirements documented'
            });
        } else {
            compliance.push({
                rule: 'Multi-Factor Authentication',
                status: 'non-compliant',
                description: 'Multi-factor authentication not mentioned'
            });
        }

        if (content.toLowerCase().includes('iso') || content.toLowerCase().includes('soc 2') || content.toLowerCase().includes('gdpr')) {
            compliance.push({
                rule: 'Regulatory Compliance Standards',
                status: 'compliant',
                description: 'Industry standard compliance frameworks referenced'
            });
        } else {
            compliance.push({
                rule: 'Regulatory Compliance Standards',
                status: 'non-compliant',
                description: 'No reference to industry compliance standards'
            });
        }

        return compliance;
    };

    // Generate policy status data based on policy type
    const getPolicyStatusData = (): PolicyStatus[] => {
        const baseData: PolicyStatus[] = [
            {
                category: 'Active Policies',
                count: Math.floor(Math.random() * 15) + 10,
                icon: 'active',
                description: 'Do not need attention',
                color: 'green'
            },
            {
                category: 'Expiring Soon',
                count: Math.floor(Math.random() * 5) + 1,
                icon: 'expiring',
                description: 'Re-Request required',
                color: 'red'
            },
            {
                category: 'Need Validation',
                count: Math.floor(Math.random() * 7) + 2,
                icon: 'validation',
                description: 'Validation required',
                color: 'yellow'
            },
            {
                category: 'Recently Expired',
                count: Math.floor(Math.random() * 4) + 1,
                icon: 'expired',
                description: 'Assign Responsibilities',
                color: 'orange'
            }
        ];

        return baseData;
    };

    const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setIsUploading(true);

            try {
                const content = await extractFileContent(file);

                setTimeout(() => {
                    setUploadedDocument({
                        name: file.name,
                        size: file.size,
                        type: file.type,
                        content: content
                    });
                    setIsUploading(false);
                }, 1000);
            } catch (error) {
                console.error('Error reading file:', error);
                setIsUploading(false);
            }
        }
    };

    const formatFileSize = (bytes: number) => {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    };

    const complianceData = uploadedDocument ? analyzeCompliance(uploadedDocument.content) : [];
    const compliantCount = complianceData.filter(item => item.status === 'compliant').length;
    const nonCompliantCount = complianceData.filter(item => item.status === 'non-compliant').length;
    const policyStatusData = getPolicyStatusData();

    const IconComponent = ({ type }: { type: 'active' | 'expiring' | 'validation' | 'expired' }) => {
        switch (type) {
            case 'active':
                return <CheckCircle2 className="size-6 text-green-600" />;
            case 'expiring':
                return <X className="size-6 text-red-600" />;
            case 'validation':
                return <AlertTriangle className="size-6 text-yellow-600" />;
            case 'expired':
                return <Hash className="size-6 text-orange-600" />;
        }
    };

    const getColorClasses = (color: string) => {
        switch (color) {
            case 'green':
                return { bg: 'bg-green-100', text: 'text-green-700', hover: 'hover:bg-green-200' };
            case 'red':
                return { bg: 'bg-red-100', text: 'text-red-700', hover: 'hover:bg-red-200' };
            case 'yellow':
                return { bg: 'bg-yellow-100', text: 'text-yellow-700', hover: 'hover:bg-yellow-200' };
            case 'orange':
                return { bg: 'bg-orange-100', text: 'text-orange-700', hover: 'hover:bg-orange-200' };
            default:
                return { bg: 'bg-gray-100', text: 'text-gray-700', hover: 'hover:bg-gray-200' };
        }
    };

    const getPrimaryGradient = () => {
        return variant === 'admin'
            ? 'from-purple-100 to-indigo-100'
            : 'from-teal-100 to-blue-100';
    };

    const getPrimaryColor = () => {
        return variant === 'admin' ? 'purple' : 'teal';
    };

    const getSecondaryColor = () => {
        return variant === 'admin' ? 'indigo' : 'blue';
    };

    const getTextColor = () => {
        return variant === 'admin' ? 'text-purple-600' : 'text-teal-600';
    };

    const getBorderColor = () => {
        return variant === 'admin' ? 'border-purple-200' : 'border-teal-200';
    };

    const getBgColor = () => {
        return variant === 'admin' ? 'bg-purple-600' : 'bg-teal-600';
    };

    const getHoverBorderColor = () => {
        return variant === 'admin' ? 'hover:border-purple-500' : 'hover:border-teal-500';
    };

    const getHoverBgColor = () => {
        return variant === 'admin' ? 'hover:bg-purple-50/50' : 'hover:bg-teal-50/50';
    };

    const getGradientFrom = () => {
        return variant === 'admin' ? 'from-purple-50' : 'from-teal-50';
    };

    const getGradientTo = () => {
        return variant === 'admin' ? 'to-indigo-50' : 'to-blue-50';
    };

    const getTextGradient = () => {
        return variant === 'admin'
            ? 'from-purple-600 to-indigo-600'
            : 'from-teal-600 to-blue-600';
    };

    const getBorder2Color = () => {
        return variant === 'admin' ? 'border-purple-100' : 'border-teal-100';
    };

    const getTextPrimary = () => {
        return variant === 'admin' ? 'text-purple-700' : 'text-teal-700';
    };

    const getTextSecondary = () => {
        return variant === 'admin' ? 'text-purple-600' : 'text-teal-600';
    };

    const getSpinColor = () => {
        return variant === 'admin' ? 'border-purple-600' : 'border-teal-600';
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center gap-3">
                <div className={`p-3 bg-gradient-to-r ${getPrimaryGradient()} rounded-xl`}>
                    <File className={`size-6 ${getTextColor()}`} />
                </div>
                <div>
                    <h2 className={`text-2xl font-bold bg-gradient-to-r ${getTextGradient()} bg-clip-text text-transparent`}>
                        {policyType}
                    </h2>
                    <p className="text-gray-600 text-sm">Upload and analyze policy documents</p>
                </div>
            </div>

            {/* Upload Section - Collapsible */}
            <div className={`border-2 ${getBorderColor()} rounded-xl overflow-hidden bg-white shadow-md`}>
                <button
                    onClick={() => setIsUploadSectionExpanded(!isUploadSectionExpanded)}
                    className={`w-full flex items-center justify-between px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} hover:${getGradientFrom().replace('from-', 'from-').replace('-50', '-100')} hover:${getGradientTo().replace('to-', 'to-').replace('-50', '-100')} transition-all`}
                >
                    <div className="flex items-center gap-3">
                        <div className={`p-2 ${getBgColor()} rounded-lg`}>
                            <Upload className="size-5 text-white" />
                        </div>
                        <div className="text-left">
                            <h3 className={`font-bold ${getTextPrimary()}`}>Upload Policy Document</h3>
                            <p className={`text-xs ${getTextSecondary()}`}>PDF, Word, CSV, or Excel files</p>
                        </div>
                    </div>
                    {isUploadSectionExpanded ? (
                        <ChevronUp className={`size-5 ${getTextSecondary()}`} />
                    ) : (
                        <ChevronDown className={`size-5 ${getTextSecondary()}`} />
                    )}
                </button>

                {isUploadSectionExpanded && (
                    <div className={`p-5 border-t-2 ${getBorder2Color()}`}>
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileSelect}
                            accept=".pdf,.doc,.docx,.csv,.xls,.xlsx"
                            className="hidden"
                        />

                        <div
                            onClick={() => fileInputRef.current?.click()}
                            className={`border-2 border-dashed ${getBorderColor()} rounded-xl p-8 text-center cursor-pointer ${getHoverBorderColor()} ${getHoverBgColor()} transition-all`}
                        >
                            <div className="flex flex-col items-center gap-3">
                                <div className={`p-4 bg-gradient-to-r ${getPrimaryGradient()} rounded-full`}>
                                    <Upload className={`size-8 ${getTextColor()}`} />
                                </div>
                                <div>
                                    <p className="font-semibold text-gray-700">Click to upload policy document</p>
                                    <p className="text-sm text-gray-500 mt-1">or drag and drop file here</p>
                                </div>
                                <p className="text-xs text-gray-400">Supported: PDF, DOC, DOCX, CSV, XLS, XLSX</p>
                            </div>
                        </div>

                        {isUploading && (
                            <div className="mt-4 flex items-center justify-center gap-3 text-gray-600">
                                <div className={`size-5 border-2 ${getSpinColor()} border-t-transparent rounded-full animate-spin`} />
                                <span>Processing document...</span>
                            </div>
                        )}

                        {uploadedDocument && !isUploading && (
                            <div className={`mt-4 flex items-center justify-between bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} rounded-lg px-4 py-3 border ${getBorderColor()}`}>
                                <div className="flex items-center gap-3">
                                    <File className={`size-5 ${getTextColor()}`} />
                                    <div>
                                        <p className="text-sm font-medium text-gray-700">{uploadedDocument.name}</p>
                                        <p className="text-xs text-gray-500">{formatFileSize(uploadedDocument.size)}</p>
                                    </div>
                                </div>
                                <button
                                    onClick={() => setUploadedDocument(null)}
                                    className="p-1.5 hover:bg-red-100 rounded-lg transition-colors"
                                >
                                    <X className="size-4 text-red-500" />
                                </button>
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* File Text Content Display */}
            {uploadedDocument && (
                <>
                    <div className="bg-white rounded-xl border-2 border-gray-200 shadow-md overflow-hidden">
                        <div className={`px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} border-b-2 ${getBorder2Color()}`}>
                            <h3 className={`font-bold ${getTextPrimary()} flex items-center gap-2`}>
                                <File className="size-5" />
                                Document Content
                            </h3>
                            <p className={`text-xs ${getTextSecondary()} mt-1`}>Extracted text from uploaded file</p>
                        </div>
                        <div className="p-5 max-h-96 overflow-y-auto bg-gray-50">
                            <pre className="whitespace-pre-wrap text-sm text-gray-700 font-mono leading-relaxed">
                                {uploadedDocument.content}
                            </pre>
                        </div>
                    </div>

                    {/* Compliance and Non-Compliance Section */}
                    <div className="bg-white rounded-xl border-2 border-gray-200 shadow-md overflow-hidden">
                        <div className={`px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} border-b-2 ${getBorder2Color()}`}>
                            <h3 className={`font-bold ${getTextPrimary()} flex items-center gap-2`}>
                                <AlertCircle className="size-5" />
                                Compliance Analysis
                            </h3>
                            <p className={`text-xs ${getTextSecondary()} mt-1`}>
                                Based on document content - {compliantCount} compliant, {nonCompliantCount} non-compliant
                            </p>
                        </div>
                        <div className="p-5">
                            <div className="grid md:grid-cols-2 gap-4">
                                {/* Compliant Items */}
                                <div className="space-y-3">
                                    <div className="flex items-center gap-2 mb-3">
                                        <CheckCircle2 className="size-5 text-green-600" />
                                        <h4 className="font-bold text-green-700">Compliant ({compliantCount})</h4>
                                    </div>
                                    {complianceData.filter(item => item.status === 'compliant').map((item, index) => (
                                        <div key={index} className="bg-green-50 border-l-4 border-green-500 rounded-lg p-4">
                                            <p className="font-semibold text-green-800 text-sm">{item.rule}</p>
                                            <p className="text-xs text-green-600 mt-1">{item.description}</p>
                                        </div>
                                    ))}
                                </div>

                                {/* Non-Compliant Items */}
                                <div className="space-y-3">
                                    <div className="flex items-center gap-2 mb-3">
                                        <AlertTriangle className="size-5 text-red-600" />
                                        <h4 className="font-bold text-red-700">Non-Compliant ({nonCompliantCount})</h4>
                                    </div>
                                    {complianceData.filter(item => item.status === 'non-compliant').map((item, index) => (
                                        <div key={index} className="bg-red-50 border-l-4 border-red-500 rounded-lg p-4">
                                            <p className="font-semibold text-red-800 text-sm">{item.rule}</p>
                                            <p className="text-xs text-red-600 mt-1">{item.description}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            )}

            {/* Policy Status Table */}
            <div className="bg-white rounded-xl border-2 border-gray-200 shadow-md overflow-hidden">
                <div className={`px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} border-b-2 ${getBorder2Color()}`}>
                    <h3 className={`font-bold ${getTextPrimary()} flex items-center gap-2`}>
                        <AlertCircle className="size-5" />
                        Policy Status Report
                    </h3>
                    <p className={`text-xs ${getTextSecondary()} mt-1`}>Overview of all {policyType.toLowerCase()} status</p>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-100 border-b-2 border-gray-200">
                            <tr>
                                <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Status</th>
                                <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Count</th>
                                <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Description</th>
                                <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Action Required</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {policyStatusData.map((status, index) => {
                                const colorClasses = getColorClasses(status.color);
                                return (
                                    <tr key={index} className="hover:bg-gray-50 transition-colors">
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-3">
                                                <IconComponent type={status.icon} />
                                                <span className="font-semibold text-gray-800">{status.category}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className={`inline-flex items-center justify-center min-w-[40px] px-3 py-1.5 rounded-full font-bold text-sm ${colorClasses.bg} ${colorClasses.text}`}>
                                                {status.count}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-gray-600 text-sm">{status.description}</td>
                                        <td className="px-6 py-4">
                                            <button className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${colorClasses.bg} ${colorClasses.text} ${colorClasses.hover}`}>
                                                View Details
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>

                {/* Summary Footer */}
                <div className={`px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} border-t-2 ${getBorder2Color()}`}>
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">
                            Total Policies: <span className="font-bold text-gray-800">{policyStatusData.reduce((sum, item) => sum + item.count, 0)}</span>
                        </span>
                        <span className="text-gray-600">
                            Requiring Attention: <span className="font-bold text-red-600">
                                {policyStatusData.filter(s => s.icon !== 'active').reduce((sum, item) => sum + item.count, 0)}
                            </span>
                        </span>
                    </div>
                </div>
            </div>

            {/* Email Report Section */}
            <EmailReportSection category={policyType} variant={variant} />
        </div>
    );
}