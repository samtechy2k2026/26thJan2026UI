import json
import os
from typing import List, Dict, Any, Optional

class DataManager:
    def __init__(self, data_path: str = "data.json"):
        self.data_path = data_path
        self.data = self._load_data()

    def _load_data(self) -> Dict[str, List[Dict[str, Any]]]:
        if os.path.exists(self.data_path):
            try:
                with open(self.data_path, "r") as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error loading data: {e}")
                return self._get_initial_data()
        else:
            initial_data = self._get_initial_data()
            self._save_data(initial_data)
            return initial_data

    def _save_data(self, data: Optional[Dict[str, List[Dict[str, Any]]]] = None):
        if data is None:
            data = self.data
        try:
            with open(self.data_path, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving data: {e}")

    def _get_initial_data(self) -> Dict[str, List[Dict[str, Any]]]:
        # Pre-populating with mock data provided by the user
        return {
            "onboarding": [
                { "id": 'ONB001', "employeeName": 'John Doe', "department": 'Engineering', "startDate": '2026-01-20', "status": 'In Progress', "assignedTo": 'Sarah Miller' },
                { "id": 'ONB002', "employeeName": 'Jane Smith', "department": 'Marketing', "startDate": '2026-01-22', "status": 'Completed', "assignedTo": 'Mike Johnson' },
            ],
            "offboarding": [
                { "id": 'OFF001', "employeeName": 'Alex Turner', "department": 'Engineering', "lastDay": '2026-01-31', "status": 'In Progress', "exitReason": 'Resignation', "assetReturn": 'Pending' },
            ],
            "invoice": [
                { "invoiceNumber": 'INV-2026-001', "client": 'Acme Corp', "amount": '$12,500.00', "issueDate": '2026-01-05', "dueDate": '2026-02-05', "status": 'Paid' },
            ],
            "variance": [
                { "projectId": 'PRJ-001', "projectName": 'Website Redesign', "budgetPlanned": '$50,000', "budgetActual": '$48,500', "variance": '+$1,500', "status": 'Under Budget', "category": 'Budget' },
            ],
            "policy": [
                { "policyId": 'POL-001', "policyName": 'Remote Work Policy', "category": 'HR', "version": '2.1', "effectiveDate": '2026-01-01', "lastReviewed": '2025-12-15', "status": 'Active' },
            ],
            "newOnboardingDocs": [
                { "docId": 'DOC-001', "documentName": 'Employee Handbook 2026', "uploadedBy": 'HR Admin', "uploadDate": '2026-01-02', "fileType": 'PDF', "size": '2.4 MB', "status": 'Approved' },
            ]
        }

    def get_records(self, category: str) -> List[Dict[str, Any]]:
        return self.data.get(category, [])

    def add_record(self, category: str, record: Dict[str, Any]):
        if category not in self.data:
            self.data[category] = []
        self.data[category].append(record)
        self._save_data()

    def delete_record(self, category: str, field: str, value: Any):
        if category in self.data:
            self.data[category] = [r for r in self.data[category] if r.get(field) != value]
            self._save_data()

    def update_record(self, category: str, field: str, value: Any, updated_record: Dict[str, Any]):
        if category in self.data:
            for i, r in enumerate(self.data[category]):
                if r.get(field) == value:
                    self.data[category][i] = updated_record
                    break
            self._save_data()
