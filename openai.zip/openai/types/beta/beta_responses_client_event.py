# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from ..._utils import PropertyInfo
from ..._models import BaseModel
from .beta_tool import BetaTool
from .beta_response_input import BetaResponseInput
from .beta_response_prompt import BetaResponsePrompt
from .beta_tool_choice_mcp import BetaToolChoiceMcp
from .beta_tool_choice_shell import BetaToolChoiceShell
from .beta_tool_choice_types import BetaToolChoiceTypes
from .beta_tool_choice_custom import BetaToolChoiceCustom
from .beta_response_includable import BetaResponseIncludable
from .beta_tool_choice_allowed import BetaToolChoiceAllowed
from .beta_tool_choice_options import BetaToolChoiceOptions
from .beta_response_text_config import BetaResponseTextConfig
from .beta_tool_choice_function import BetaToolChoiceFunction
from .beta_response_inject_event import BetaResponseInjectEvent
from .beta_tool_choice_apply_patch import BetaToolChoiceApplyPatch
from .beta_response_conversation_param import BetaResponseConversationParam

__all__ = [
    "BetaResponsesClientEvent",
    "ResponseCreate",
    "ResponseCreateContextManagement",
    "ResponseCreateConversation",
    "ResponseCreateModeration",
    "ResponseCreateModerationPolicy",
    "ResponseCreateModerationPolicyInput",
    "ResponseCreateModerationPolicyOutput",
    "ResponseCreateMultiAgent",
    "ResponseCreatePromptCacheOptions",
    "ResponseCreateReasoning",
    "ResponseCreateStreamOptions",
    "ResponseCreateToolChoice",
    "ResponseCreateToolChoiceBetaSpecificProgrammaticToolCallingParam",
]


class ResponseCreateContextManagement(BaseModel):
    type: str
    """The context management entry type. Currently only 'compaction' is supported."""

    compact_threshold: Optional[int] = None
    """Token threshold at which compaction should be triggered for this entry."""


ResponseCreateConversation: TypeAlias = Union[str, BetaResponseConversationParam, None]


class ResponseCreateModerationPolicyInput(BaseModel):
    """The moderation policy for the response input."""

    mode: Literal["score", "block"]


class ResponseCreateModerationPolicyOutput(BaseModel):
    """The moderation policy for the response output."""

    mode: Literal["score", "block"]


class ResponseCreateModerationPolicy(BaseModel):
    """The policy to apply to moderated response input and output."""

    input: Optional[ResponseCreateModerationPolicyInput] = None
    """The moderation policy for the response input."""

    output: Optional[ResponseCreateModerationPolicyOutput] = None
    """The moderation policy for the response output."""


class ResponseCreateModeration(BaseModel):
    """Configuration for running moderation on the input and output of this response."""

    model: str
    """The moderation model to use for moderated completions, e.g.

    'omni-moderation-latest'.
    """

    policy: Optional[ResponseCreateModerationPolicy] = None
    """The policy to apply to moderated response input and output."""


class ResponseCreateMultiAgent(BaseModel):
    """Configuration for server-hosted multi-agent execution."""

    enabled: bool
    """Whether to enable server-hosted multi-agent execution for this response."""

    max_concurrent_subagents: Optional[int] = None
    """
    `max_concurrent_subagents` sets the maximum number of subagents that can be
    active simultaneously across the entire agent tree. It includes all
    descendants—children, grandchildren, and deeper subagents—but excludes the root
    agent. The API does not impose a fixed upper bound on this setting. The default
    is `3`, which is recommended for most workloads. Multi-agent runs also have no
    fixed limit on tree depth or the total number of subagents created during a run.
    """


class ResponseCreatePromptCacheOptions(BaseModel):
    """Options for prompt caching.

    Supported for `gpt-5.6` and later models. By default, OpenAI automatically chooses one implicit cache breakpoint. You can add explicit breakpoints to content blocks with `prompt_cache_breakpoint`. Each request can write up to four breakpoints. For cache matching, OpenAI considers up to the latest 80 breakpoints in the conversation, without a content-block lookback limit. Set `mode` to `explicit` to disable the implicit breakpoint. The `ttl` defaults to `30m`, which is currently the only supported value. See the [prompt caching guide](https://platform.openai.com/docs/guides/prompt-caching) for current details.
    """

    mode: Optional[Literal["implicit", "explicit"]] = None
    """Controls whether OpenAI automatically creates an implicit cache breakpoint.

    Defaults to `implicit`. With `implicit`, OpenAI creates one implicit breakpoint
    and writes up to the latest three explicit breakpoints in the request. With
    `explicit`, OpenAI does not create an implicit breakpoint and writes up to the
    latest four explicit breakpoints. If there are no explicit breakpoints, the
    request does not use prompt caching.
    """

    ttl: Optional[Literal["30m"]] = None
    """
    The minimum lifetime applied to every implicit and explicit cache breakpoint
    written by the request. Defaults to `30m`, which is currently the only supported
    value. The backend may retain cache entries for longer.
    """


class ResponseCreateReasoning(BaseModel):
    """**gpt-5 and o-series models only**

    Configuration options for
    [reasoning models](https://platform.openai.com/docs/guides/reasoning).
    """

    context: Optional[Literal["auto", "current_turn", "all_turns"]] = None
    """
    Controls which reasoning items are rendered back to the model on later turns.
    When returned on a response, this is the effective reasoning context mode used
    for the response.
    """

    effort: Optional[Literal["none", "minimal", "low", "medium", "high", "xhigh", "max"]] = None
    """Constrains effort on reasoning for reasoning models.

    Currently supported values are `none`, `minimal`, `low`, `medium`, `high`,
    `xhigh`, and `max`. Reducing reasoning effort can result in faster responses and
    fewer tokens used on reasoning in a response. Not all reasoning models support
    every value. See the
    [reasoning guide](https://platform.openai.com/docs/guides/reasoning) for
    model-specific support.
    """

    generate_summary: Optional[Literal["auto", "concise", "detailed"]] = None
    """**Deprecated:** use `summary` instead.

    A summary of the reasoning performed by the model. This can be useful for
    debugging and understanding the model's reasoning process. One of `auto`,
    `concise`, or `detailed`.
    """

    mode: Union[str, Literal["standard", "pro"], None] = None
    """Controls the reasoning execution mode for the request.

    When returned on a response, this is the effective execution mode.
    """

    summary: Optional[Literal["auto", "concise", "detailed"]] = None
    """A summary of the reasoning performed by the model.

    This can be useful for debugging and understanding the model's reasoning
    process. One of `auto`, `concise`, or `detailed`.

    `concise` is supported for `computer-use-preview` models and all reasoning
    models after `gpt-5`.
    """


class ResponseCreateStreamOptions(BaseModel):
    """Options for streaming responses. Only set this when you set `stream: true`."""

    include_obfuscation: Optional[bool] = None
    """When true, stream obfuscation will be enabled.

    Stream obfuscation adds random characters to an `obfuscation` field on streaming
    delta events to normalize payload sizes as a mitigation to certain side-channel
    attacks. These obfuscation fields are included by default, but add a small
    amount of overhead to the data stream. You can set `include_obfuscation` to
    false to optimize for bandwidth if you trust the network links between your
    application and the OpenAI API.
    """


class ResponseCreateToolChoiceBetaSpecificProgrammaticToolCallingParam(BaseModel):
    type: Literal["programmatic_tool_calling"]
    """The tool to call. Always `programmatic_tool_calling`."""


ResponseCreateToolChoice: TypeAlias = Union[
    BetaToolChoiceOptions,
    BetaToolChoiceAllowed,
    BetaToolChoiceTypes,
    BetaToolChoiceFunction,
    BetaToolChoiceMcp,
    BetaToolChoiceCustom,
    ResponseCreateToolChoiceBetaSpecificProgrammaticToolCallingParam,
    BetaToolChoiceApplyPatch,
    BetaToolChoiceShell,
]


class ResponseCreate(BaseModel):
    """
    Client event for creating a response over a persistent WebSocket connection.
    This payload uses the same top-level fields as `POST /v1/responses`.

    Notes:
    - `stream` is implicit over WebSocket and should not be sent.
    - `background` is not supported over WebSocket.
    """

    type: Literal["response.create"]
    """The type of the client event. Always `response.create`."""

    background: Optional[bool] = None
    """
    Whether to run the model response in the background.
    [Learn more](https://platform.openai.com/docs/guides/background).
    """

    context_management: Optional[List[ResponseCreateContextManagement]] = None
    """Context management configuration for this request."""

    conversation: Optional[ResponseCreateConversation] = None
    """The conversation that this response belongs to.

    Items from this conversation are prepended to `input_items` for this response
    request. Input items and output items from this response are automatically added
    to this conversation after this response completes.
    """

    include: Optional[List[BetaResponseIncludable]] = None
    """Specify additional output data to include in the model response.

    Currently supported values are:

    - `web_search_call.action.sources`: Include the sources of the web search tool
      call.
    - `code_interpreter_call.outputs`: Includes the outputs of python code execution
      in code interpreter tool call items.
    - `computer_call_output.output.image_url`: Include image urls from the computer
      call output.
    - `file_search_call.results`: Include the search results of the file search tool
      call.
    - `message.input_image.image_url`: Include image urls from the input message.
    - `message.output_text.logprobs`: Include logprobs with assistant messages.
    - `reasoning.encrypted_content`: Includes an encrypted version of reasoning
      tokens in reasoning item outputs. This enables reasoning items to be used in
      multi-turn conversations when using the Responses API statelessly (like when
      the `store` parameter is set to `false`, or when an organization is enrolled
      in the zero data retention program).
    """

    input: Union[str, BetaResponseInput, None] = None
    """Text, image, or file inputs to the model, used to generate a response.

    Learn more:

    - [Text inputs and outputs](https://platform.openai.com/docs/guides/text)
    - [Image inputs](https://platform.openai.com/docs/guides/images)
    - [File inputs](https://platform.openai.com/docs/guides/pdf-files)
    - [Conversation state](https://platform.openai.com/docs/guides/conversation-state)
    - [Function calling](https://platform.openai.com/docs/guides/function-calling)
    """

    instructions: Optional[str] = None
    """A system (or developer) message inserted into the model's context.

    When using along with `previous_response_id`, the instructions from a previous
    response will not be carried over to the next response. This makes it simple to
    swap out system (or developer) messages in new responses.
    """

    max_output_tokens: Optional[int] = None
    """
    An upper bound for the number of tokens that can be generated for a response,
    including visible output tokens and
    [reasoning tokens](https://platform.openai.com/docs/guides/reasoning).
    """

    max_tool_calls: Optional[int] = None
    """
    The maximum number of total calls to built-in tools that can be processed in a
    response. This maximum number applies across all built-in tool calls, not per
    individual tool. Any further attempts to call a tool by the model will be
    ignored.
    """

    metadata: Optional[Dict[str, str]] = None
    """Set of 16 key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard.

    Keys are strings with a maximum length of 64 characters. Values are strings with
    a maximum length of 512 characters.
    """

    model: Union[
        Literal[
            "gpt-5.6-sol",
            "gpt-5.6-terra",
            "gpt-5.6-luna",
            "gpt-5.4",
            "gpt-5.4-mini",
            "gpt-5.4-nano",
            "gpt-5.4-mini-2026-03-17",
            "gpt-5.4-nano-2026-03-17",
            "gpt-5.3-chat-latest",
            "gpt-5.2",
            "gpt-5.2-2025-12-11",
            "gpt-5.2-chat-latest",
            "gpt-5.2-pro",
            "gpt-5.2-pro-2025-12-11",
            "gpt-5.1",
            "gpt-5.1-2025-11-13",
            "gpt-5.1-codex",
            "gpt-5.1-mini",
            "gpt-5.1-chat-latest",
            "gpt-5",
            "gpt-5-mini",
            "gpt-5-nano",
            "gpt-5-2025-08-07",
            "gpt-5-mini-2025-08-07",
            "gpt-5-nano-2025-08-07",
            "gpt-5-chat-latest",
            "gpt-4.1",
            "gpt-4.1-mini",
            "gpt-4.1-nano",
            "gpt-4.1-2025-04-14",
            "gpt-4.1-mini-2025-04-14",
            "gpt-4.1-nano-2025-04-14",
            "o4-mini",
            "o4-mini-2025-04-16",
            "o3",
            "o3-2025-04-16",
            "o3-mini",
            "o3-mini-2025-01-31",
            "o1",
            "o1-2024-12-17",
            "o1-preview",
            "o1-preview-2024-09-12",
            "o1-mini",
            "o1-mini-2024-09-12",
            "gpt-4o",
            "gpt-4o-2024-11-20",
            "gpt-4o-2024-08-06",
            "gpt-4o-2024-05-13",
            "gpt-4o-audio-preview",
            "gpt-4o-audio-preview-2024-10-01",
            "gpt-4o-audio-preview-2024-12-17",
            "gpt-4o-audio-preview-2025-06-03",
            "gpt-4o-mini-audio-preview",
            "gpt-4o-mini-audio-preview-2024-12-17",
            "gpt-4o-search-preview",
            "gpt-4o-mini-search-preview",
            "gpt-4o-search-preview-2025-03-11",
            "gpt-4o-mini-search-preview-2025-03-11",
            "chatgpt-4o-latest",
            "codex-mini-latest",
            "gpt-4o-mini",
            "gpt-4o-mini-2024-07-18",
            "gpt-4-turbo",
            "gpt-4-turbo-2024-04-09",
            "gpt-4-0125-preview",
            "gpt-4-turbo-preview",
            "gpt-4-1106-preview",
            "gpt-4-vision-preview",
            "gpt-4",
            "gpt-4-0314",
            "gpt-4-0613",
            "gpt-4-32k",
            "gpt-4-32k-0314",
            "gpt-4-32k-0613",
            "gpt-3.5-turbo",
            "gpt-3.5-turbo-16k",
            "gpt-3.5-turbo-0301",
            "gpt-3.5-turbo-0613",
            "gpt-3.5-turbo-1106",
            "gpt-3.5-turbo-0125",
            "gpt-3.5-turbo-16k-0613",
            "o1-pro",
            "o1-pro-2025-03-19",
            "o3-pro",
            "o3-pro-2025-06-10",
            "o3-deep-research",
            "o3-deep-research-2025-06-26",
            "o4-mini-deep-research",
            "o4-mini-deep-research-2025-06-26",
            "computer-use-preview",
            "computer-use-preview-2025-03-11",
            "gpt-5-codex",
            "gpt-5-pro",
            "gpt-5-pro-2025-10-06",
            "gpt-5.1-codex-max",
        ],
        str,
        None,
    ] = None
    """Model ID used to generate the response, like `gpt-4o` or `o3`.

    OpenAI offers a wide range of models with different capabilities, performance
    characteristics, and price points. Refer to the
    [model guide](https://platform.openai.com/docs/models) to browse and compare
    available models.
    """

    moderation: Optional[ResponseCreateModeration] = None
    """Configuration for running moderation on the input and output of this response."""

    multi_agent: Optional[ResponseCreateMultiAgent] = None
    """Configuration for server-hosted multi-agent execution."""

    parallel_tool_calls: Optional[bool] = None
    """Whether to allow the model to run tool calls in parallel."""

    previous_response_id: Optional[str] = None
    """The unique ID of the previous response to the model.

    Use this to create multi-turn conversations. Learn more about
    [conversation state](https://platform.openai.com/docs/guides/conversation-state).
    Cannot be used in conjunction with `conversation`.
    """

    prompt: Optional[BetaResponsePrompt] = None
    """
    Reference to a prompt template and its variables.
    [Learn more](https://platform.openai.com/docs/guides/text?api-mode=responses#reusable-prompts).
    """

    prompt_cache_key: Optional[str] = None
    """
    Used by OpenAI to cache responses for similar requests to optimize your cache
    hit rates. Replaces the `user` field.
    [Learn more](https://platform.openai.com/docs/guides/prompt-caching).
    """

    prompt_cache_options: Optional[ResponseCreatePromptCacheOptions] = None
    """Options for prompt caching.

    Supported for `gpt-5.6` and later models. By default, OpenAI automatically
    chooses one implicit cache breakpoint. You can add explicit breakpoints to
    content blocks with `prompt_cache_breakpoint`. Each request can write up to four
    breakpoints. For cache matching, OpenAI considers up to the latest 80
    breakpoints in the conversation, without a content-block lookback limit. Set
    `mode` to `explicit` to disable the implicit breakpoint. The `ttl` defaults to
    `30m`, which is currently the only supported value. See the
    [prompt caching guide](https://platform.openai.com/docs/guides/prompt-caching)
    for current details.
    """

    prompt_cache_retention: Optional[Literal["in_memory", "24h"]] = None
    """Deprecated. Use `prompt_cache_options.ttl` instead.

    The retention policy for the prompt cache. Set to `24h` to enable extended
    prompt caching, which keeps cached prefixes active for longer, up to a maximum
    of 24 hours.
    [Learn more](https://platform.openai.com/docs/guides/prompt-caching#prompt-cache-retention).
    This field expresses a maximum retention policy, while
    `prompt_cache_options.ttl` expresses a minimum cache lifetime. The two fields
    are independent and do not interact. For `gpt-5.5`, `gpt-5.5-pro`, and future
    models, only `24h` is supported.

    For older models that support both `in_memory` and `24h`, the default depends on
    your organization's data retention policy:

    - Organizations without ZDR enabled default to `24h`.
    - Organizations with ZDR enabled default to `in_memory` when
      `prompt_cache_retention` is not specified.
    """

    reasoning: Optional[ResponseCreateReasoning] = None
    """**gpt-5 and o-series models only**

    Configuration options for
    [reasoning models](https://platform.openai.com/docs/guides/reasoning).
    """

    safety_identifier: Optional[str] = None
    """
    A stable identifier used to help detect users of your application that may be
    violating OpenAI's usage policies. The IDs should be a string that uniquely
    identifies each user, with a maximum length of 64 characters. We recommend
    hashing their username or email address, in order to avoid sending us any
    identifying information.
    [Learn more](https://platform.openai.com/docs/guides/safety-best-practices#safety-identifiers).
    """

    service_tier: Optional[Literal["auto", "default", "flex", "scale", "priority"]] = None
    """Specifies the processing type used for serving the request.

    - If set to 'auto', then the request will be processed with the service tier
      configured in the Project settings. Unless otherwise configured, the Project
      will use 'default'.
    - If set to 'default', then the request will be processed with the standard
      pricing and performance for the selected model.
    - If set to '[flex](https://platform.openai.com/docs/guides/flex-processing)' or
      '[priority](https://openai.com/api-priority-processing/)', then the request
      will be processed with the corresponding service tier.
    - When not set, the default behavior is 'auto'.

    When the `service_tier` parameter is set, the response body will include the
    `service_tier` value based on the processing mode actually used to serve the
    request. This response value may be different from the value set in the
    parameter.
    """

    store: Optional[bool] = None
    """Whether to store the generated model response for later retrieval via API."""

    stream: Optional[bool] = None
    """
    If set to true, the model response data will be streamed to the client as it is
    generated using
    [server-sent events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events#Event_stream_format).
    See the
    [Streaming section below](https://platform.openai.com/docs/api-reference/responses-streaming)
    for more information.
    """

    stream_options: Optional[ResponseCreateStreamOptions] = None
    """Options for streaming responses. Only set this when you set `stream: true`."""

    temperature: Optional[float] = None
    """What sampling temperature to use, between 0 and 2.

    Higher values like 0.8 will make the output more random, while lower values like
    0.2 will make it more focused and deterministic. We generally recommend altering
    this or `top_p` but not both.
    """

    text: Optional[BetaResponseTextConfig] = None
    """Configuration options for a text response from the model.

    Can be plain text or structured JSON data. Learn more:

    - [Text inputs and outputs](https://platform.openai.com/docs/guides/text)
    - [Structured Outputs](https://platform.openai.com/docs/guides/structured-outputs)
    """

    tool_choice: Optional[ResponseCreateToolChoice] = None
    """
    How the model should select which tool (or tools) to use when generating a
    response. See the `tools` parameter to see how to specify which tools the model
    can call.
    """

    tools: Optional[List[BetaTool]] = None
    """An array of tools the model may call while generating a response.

    You can specify which tool to use by setting the `tool_choice` parameter.

    We support the following categories of tools:

    - **Built-in tools**: Tools that are provided by OpenAI that extend the model's
      capabilities, like
      [web search](https://platform.openai.com/docs/guides/tools-web-search) or
      [file search](https://platform.openai.com/docs/guides/tools-file-search).
      Learn more about
      [built-in tools](https://platform.openai.com/docs/guides/tools).
    - **MCP Tools**: Integrations with third-party systems via custom MCP servers or
      predefined connectors such as Google Drive and SharePoint. Learn more about
      [MCP Tools](https://platform.openai.com/docs/guides/tools-connectors-mcp).
    - **Function calls (custom tools)**: Functions that are defined by you, enabling
      the model to call your own code with strongly typed arguments and outputs.
      Learn more about
      [function calling](https://platform.openai.com/docs/guides/function-calling).
      You can also use custom tools to call your own code.
    """

    top_logprobs: Optional[int] = None
    """
    An integer between 0 and 20 specifying the maximum number of most likely tokens
    to return at each token position, each with an associated log probability. In
    some cases, the number of returned tokens may be fewer than requested.
    """

    top_p: Optional[float] = None
    """
    An alternative to sampling with temperature, called nucleus sampling, where the
    model considers the results of the tokens with top_p probability mass. So 0.1
    means only the tokens comprising the top 10% probability mass are considered.

    We generally recommend altering this or `temperature` but not both.
    """

    truncation: Optional[Literal["auto", "disabled"]] = None
    """The truncation strategy to use for the model response.

    - `auto`: If the input to this Response exceeds the model's context window size,
      the model will truncate the response to fit the context window by dropping
      items from the beginning of the conversation.
    - `disabled` (default): If the input size will exceed the context window size
      for a model, the request will fail with a 400 error.
    """

    user: Optional[str] = None
    """This field is being replaced by `safety_identifier` and `prompt_cache_key`.

    Use `prompt_cache_key` instead to maintain caching optimizations. A stable
    identifier for your end-users. Used to boost cache hit rates by better bucketing
    similar requests and to help OpenAI detect and prevent abuse.
    [Learn more](https://platform.openai.com/docs/guides/safety-best-practices#safety-identifiers).
    """


BetaResponsesClientEvent: TypeAlias = Annotated[
    Union[ResponseCreate, BetaResponseInjectEvent], PropertyInfo(discriminator="type")
]
